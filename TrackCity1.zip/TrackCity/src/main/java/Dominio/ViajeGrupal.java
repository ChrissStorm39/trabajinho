/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.sql.Date;
import java.sql.Time;

/**
 *
 * @author GABBY
 */
public class ViajeGrupal extends Viaje{
    //atributos
    public Vehiculo capacidad ;
    public Double TarifaDelViaje ;
    //metodo constructor
    //Por Defecto

    public ViajeGrupal() {
    }
    //metodo constructor
    //con Parametros

    public ViajeGrupal(Vehiculo capacidad, Double TarifaDelViaje) {
        this.capacidad = capacidad;
        this.TarifaDelViaje = TarifaDelViaje;
    }

    public ViajeGrupal(Vehiculo capacidad, Double TarifaDelViaje, Date fechaViaje, Time horaViaje, UsuarioCliente nombreCliente, UsuarioConductor nombreConductor, Ruta idRuta) {
        super(fechaViaje, horaViaje, nombreCliente, nombreConductor, idRuta);
        this.capacidad = capacidad;
        this.TarifaDelViaje = TarifaDelViaje;
    }
    //Metodos Gett y Sett

    public Vehiculo getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(Vehiculo capacidad) {
        this.capacidad = capacidad;
    }

    public Double getTarifaDelViaje() {
        return TarifaDelViaje;
    }

    public void setTarifaDelViaje(Double TarifaDelViaje) {
        this.TarifaDelViaje = TarifaDelViaje;
    }

    public Date getFechaViaje() {
        return fechaViaje;
    }

    public void setFechaViaje(Date fechaViaje) {
        this.fechaViaje = fechaViaje;
    }

    public Time getHoraViaje() {
        return horaViaje;
    }

    public void setHoraViaje(Time horaViaje) {
        this.horaViaje = horaViaje;
    }

    public UsuarioCliente getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(UsuarioCliente nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public UsuarioConductor getNombreConductor() {
        return nombreConductor;
    }

    public void setNombreConductor(UsuarioConductor nombreConductor) {
        this.nombreConductor = nombreConductor;
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.util.Arrays;

/**
 *
 * @author GABBY
 */
//Clase Empresa
public class Empresa {
//Atributos
private Usuario[] usuarios;
//Definir clase Usuario y llamarlo
private String nombreEmpresa;
private String rucEmpresa;
//Constructor 
//Por Defecto
    public Empresa() {
        Usuario[] usuarios = new Usuario[1];
        this.usuarios = usuarios;
        this.nombreEmpresa = "TrackCity";
        this.rucEmpresa = "00000000000";
    }
//con parametros

    public Empresa(Usuario[] usuarios, String nombreEmpresa, String rucEmpresa) {
        this.usuarios = usuarios;
        this.nombreEmpresa = nombreEmpresa;
        this.rucEmpresa = rucEmpresa;
    }
    
/*Metodos Definidos en el proyecto 
     Crear un nuevo usuario*/
    
//Metodos Gett y Sett
    public Usuario[] getUsuarios() {
        return usuarios;
    }

    public void setUsuarios(Usuario[] usuarios) {
        this.usuarios = usuarios;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getRucEmpresa() {
        return rucEmpresa;
    }

    public void setRucEmpresa(String rucEmpresa) {
        this.rucEmpresa = rucEmpresa;
    }

    @Override
    public String toString() {
        return "Empresa{" + "usuarios=" + Arrays.toString(usuarios) + ", nombreEmpresa=" + nombreEmpresa + ", rucEmpresa=" + rucEmpresa + '}';
    }

    

}

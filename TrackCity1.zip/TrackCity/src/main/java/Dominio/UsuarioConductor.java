/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author GABBY
 */
public class UsuarioConductor {
    //Atributos
    private int idConductor ;
    private String licenciaDeConducir;
    //duda
    private Vehiculo[] vehiculo;
    
    //metodo constructor
    //Por Defecto

    public UsuarioConductor() {
    }
    //con parametros

    public UsuarioConductor(int idConductor, String licenciaDeConducir, Vehiculo[] vehiculo) {
        this.idConductor = idConductor;
        this.licenciaDeConducir = licenciaDeConducir;
        this.vehiculo = vehiculo;
    }
    //Metodos Gett y Sett

    public int getIdConductor() {
        return idConductor;
    }

    public void setIdConductor(int idConductor) {
        this.idConductor = idConductor;
    }

    public String getLicenciaDeConducir() {
        return licenciaDeConducir;
    }

    public void setLicenciaDeConducir(String licenciaDeConducir) {
        this.licenciaDeConducir = licenciaDeConducir;
    }

    public Vehiculo[] getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo[] vehiculo) {
        this.vehiculo = vehiculo;
    }
    
}

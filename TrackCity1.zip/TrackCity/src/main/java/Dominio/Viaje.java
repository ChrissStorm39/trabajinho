/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.sql.Date;
import java.sql.Time;

/**
 *
 * @author GABBY
 */
public class Viaje  {
    //Atributos
    public Date fechaViaje;
    public Time horaViaje;
    public UsuarioCliente nombreCliente;
    public UsuarioConductor nombreConductor;
    private Ruta idRuta;
    //metodo constructor
    //Por Defecto

    public Viaje() {
    }
    //con parametros

    public Viaje(Date fechaViaje, Time horaViaje, UsuarioCliente nombreCliente, UsuarioConductor nombreConductor, Ruta idRuta) {
        this.fechaViaje = fechaViaje;
        this.horaViaje = horaViaje;
        this.nombreCliente = nombreCliente;
        this.nombreConductor = nombreConductor;
        this.idRuta = idRuta;
    }
    //Metodos Gett y Sett

    public Date getFechaViaje() {
        return fechaViaje;
    }

    public void setFechaViaje(Date fechaViaje) {
        this.fechaViaje = fechaViaje;
    }

    public Time getHoraViaje() {
        return horaViaje;
    }

    public void setHoraViaje(Time horaViaje) {
        this.horaViaje = horaViaje;
    }

    public UsuarioCliente getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(UsuarioCliente nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public UsuarioConductor getNombreConductor() {
        return nombreConductor;
    }

    public void setNombreConductor(UsuarioConductor nombreConductor) {
        this.nombreConductor = nombreConductor;
    }

    public Ruta getIdRuta() {
        return idRuta;
    }

    public void setIdRuta(Ruta idRuta) {
        this.idRuta = idRuta;
    }
    
}

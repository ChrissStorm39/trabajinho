/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;


/**
 *
 * @author GABBY
 */
public class Vehiculo {
    //Atributos
    public String placa;
    public String matricula;
    public String marca;
    public String modelo;
    public String tipoDeVehiculo;
    public int capacidad;
    private UsuarioConductor idConductor;
    private int idVehiculo;
    //metodo constructor
    //Por Defecto

    public Vehiculo() {
    }
    //con parametros

    public Vehiculo(String placa, String matricula, String marca, String modelo, String tipoDeVehiculo, int capacidad, UsuarioConductor idConductor) {
        this.placa = placa;
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.tipoDeVehiculo = tipoDeVehiculo;
        this.capacidad = capacidad;
        this.idConductor = idConductor;
    }
    //Metodos Gett y Sett

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getTipoDeVehiculo() {
        return tipoDeVehiculo;
    }

    public void setTipoDeVehiculo(String tipoDeVehiculo) {
        this.tipoDeVehiculo = tipoDeVehiculo;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public UsuarioConductor getIdConductor() {
        return idConductor;
    }

    public void setIdConductor(UsuarioConductor idConductor) {
        this.idConductor = idConductor;
    }
    
}

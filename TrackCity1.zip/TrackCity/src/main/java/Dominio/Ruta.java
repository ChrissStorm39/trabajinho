/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

import java.sql.Time;

/**
 *
 * @author GABBY
 */
public class Ruta {
    //Atributos
    public String nombreRuta;
    public String origen;
    public String destino;
    public double distancia;
    public String duracion;
    public String cliente;
    public int idConductor;
    public int idVehiculo;
    private int idRuta;
    //metodo constructor
    //Por Defecto

    public Ruta() {
        this.nombreRuta = "RUTA 1";
        this.origen = " La Planada";
        this.destino = "UCE";
        this.distancia = 300.2;
        this.duracion = "2:00h";
        this.cliente = "Gabriel Rosero";
        this.idConductor = 001;
        this.idVehiculo = 001;
    }
     //con parametros

    public Ruta(String nombreRuta, String origen, String destino, double distancia, String duracion, String cliente, int idConductor, int idVehiculo) {
        this.nombreRuta = nombreRuta;
        this.origen = origen;
        this.destino = destino;
        this.distancia = distancia;
        this.duracion = duracion;
        this.cliente = cliente;
        this.idConductor = idConductor;
        this.idVehiculo = idVehiculo;
    }
    //Metodos Gett y Sett

    public String getNombreRuta() {
        return nombreRuta;
    }

    public void setNombreRuta(String nombreRuta) {
        this.nombreRuta = nombreRuta;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public double getDistancia() {
        return distancia;
    }

    public void setDistancia(double distancia) {
        this.distancia = distancia;
    }

    public String getDuracion() {
        return duracion;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public int getIdConductor() {
        return idConductor;
    }

    public void setIdConductor(int idConductor) {
        this.idConductor = idConductor;
    }

    public int getIdVehiculo() {
        return idVehiculo;
    }

    public void setIdVehiculo(int idVehiculo) {
        this.idVehiculo = idVehiculo;
    }

    public int getIdRuta() {
        return idRuta;
    }

    public void setIdRuta(int idRuta) {
        this.idRuta = idRuta;
    }

    @Override
    public String toString() {
        return "Ruta{" + "nombreRuta=" + nombreRuta + ", origen=" + origen + ", destino=" + destino + ", distancia=" + distancia + ", duracion=" + duracion + ", cliente=" + cliente + ", idConductor=" + idConductor + ", idVehiculo=" + idVehiculo + ", idRuta=" + idRuta + '}';
    }

    
    
}

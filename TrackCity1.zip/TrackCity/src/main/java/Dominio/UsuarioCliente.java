/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author GABBY
 */
public class UsuarioCliente extends Usuario{
    //Atributos
    private int idCliente;
    //metodo constructor
    //Por Defecto

    public UsuarioCliente() {
    }
    //con parametros
    public UsuarioCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public UsuarioCliente(int idCliente, String nombreUsuario, String contraseña, String correoElectronico, int numeroTelefono) {
        super(nombreUsuario, contraseña, correoElectronico, numeroTelefono);
        this.idCliente = idCliente;
    }
    //Metodos Gett y Sett

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }
    
}

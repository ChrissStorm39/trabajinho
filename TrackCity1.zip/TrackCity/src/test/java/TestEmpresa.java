
import Dominio.Empresa;
import Dominio.Usuario;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author GABBY
 */
public class TestEmpresa {

    public static void main(String[] args) {
        System.out.println("Constructor por defecto");
        testConstructor();
        System.out.println("CCP");
        testConstructor1();

    }

    public static void testConstructor() {
        Empresa empresa = new Empresa();
        System.out.println(empresa);
    }

    public static void testConstructor1() {
        Usuario usuarios[] = new Usuario[5];
        Empresa empresa = new Empresa(usuarios, "TrackCity", "00001727278333");
        System.out.println(empresa);
    }
}

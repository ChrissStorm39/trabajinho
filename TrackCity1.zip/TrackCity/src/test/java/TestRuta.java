
import Dominio.Empresa;
import Dominio.Ruta;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author GABBY
 */
public class TestRuta {

    public static void main(String[] args) {
        System.out.println("CONSTRUCTOR POR DEFECTO");
        testConstructor();
        System.out.println("CONSTRUCTOR CON PARAMETROS");
        testConstructor1();
    }

    public static void testConstructor() {
        Ruta ruta = new Ruta();
        System.out.println(ruta);
    }

    public static void testConstructor1() {
        Ruta ruta = new Ruta("RUTA1", "Planada", "UCE", 300, "2:00", "Gabriel Rosero", 1, 1);
        System.out.println(ruta);
    }
    
}
